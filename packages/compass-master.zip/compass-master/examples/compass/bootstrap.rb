require File.join(File.dirname(__FILE__), '..', 'downloader')

install_from_github('chriseppstein', 'yui-compass-plugin', 'yui')
install_from_github('chriseppstein', 'Compass-Layouts', 'compass-layouts')