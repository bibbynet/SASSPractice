require File.join(File.dirname(__FILE__), '..', 'downloader')

install_from_github('chriseppstein', 'compass-colors', 'compass-colors')
