$:.unshift("#{File.dirname(__FILE__)}/..")

require 'test/unit'

require 'sass'
require 'lib/bootstrap-sass/compass_functions'
require 'lib/bootstrap-sass/sass_functions'